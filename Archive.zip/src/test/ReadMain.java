package test;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Minutes;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class ReadMain {

	static int dateDifference;
	static String dateBeforeCurrentRow;

	static List<String> finalizeArray, finalizeFixedArray;

	public static void main(String[] args) throws IOException {
		// to hold final array of data that will write to excel
		finalizeArray = new ArrayList<>();
		finalizeFixedArray = new ArrayList<>();

		String csvFilename = "TestExcel3.csv";
		CSVReader csvReader = new CSVReader(new FileReader(csvFilename));

		String[] row = null;
		int countTotalRows = 0;

		System.out.println("Data analysing begins\n-------------------");
		while ((row = csvReader.readNext()) != null) {

			// variable to store row count at end
			countTotalRows++;
			System.out.println("Row " + countTotalRows + " data matched");

			// variable to hold row details
			String rowData = "", mDateTime = "";
			int count = 0;

			// go through each row's cells
			while (count < row.length) {
				if (count == 0) {
					mDateTime = mDateTime + row[count];
					rowData = rowData + row[count] + "\t";
				} else if (count == 1) {
					mDateTime = mDateTime + " " + row[count];
					rowData = rowData + row[count] + "\t";
				} else {
					rowData = rowData + row[count] + "\t";
				}
				count += 1;
			}

			// set custom for only first row
			boolean xResultAfterConditionCheck = false;
			if (countTotalRows == 1) {
				xResultAfterConditionCheck = isDifferenceOk(mDateTime, mDateTime);
				finalizeArray.add(rowData);

			} else {
				xResultAfterConditionCheck = isDifferenceOk(dateBeforeCurrentRow, mDateTime);
				if (xResultAfterConditionCheck) {
					finalizeArray.add(rowData);
				} else {
					List<String> missingRowData = getMissingRows(dateBeforeCurrentRow, mDateTime);
					for (int i = 0; i < missingRowData.size(); i++) {
						finalizeArray.add(missingRowData.get(i));
					}
				}

			}

			dateBeforeCurrentRow = mDateTime;
		}

		System.out.println("\nGenerating records array...\n");
		generateFinalizedArray();
		// for (int i = 0; i < finalizeFixedArray.size(); i++) {
		// System.out.println(finalizeFixedArray.get(i));
		// }

		System.out.println("\nCreating txt...\n");
		int i = 0;
		FileWriter writer = new FileWriter("output.txt");
		for (String str : finalizeFixedArray) {
			writer.write(str);
			writer.write(System.getProperty("line.separator"));
		}

		System.out.println("Generating CSV file...");
		String csv = "output.csv";
		CSVWriter writerCsv = new CSVWriter(new FileWriter(csv));

		for (String str : finalizeFixedArray) {
			String[] dateRow = str.split("\t");
			writerCsv.writeNext(dateRow);
		}

		writerCsv.close();

		System.out.println("Data analysing finished\n-------------------");

		csvReader.close();
		System.out.println("Total original records :" + countTotalRows);
		System.out.println("Total finalized records :" + finalizeFixedArray.size());
		System.out.println("Total fixed records :" + (finalizeFixedArray.size() - countTotalRows));
	}

	public static String getTimeResult(String date) {
		String timeStamp = date;
		String result = "";

		if (timeStamp.equals("00:00")) {
			return date;
		} else {
			return timeStamp;
		}
	}

	public static boolean isDifferenceOk(String priviousTime, String currentTime) {
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy.MM.dd HH:mm");

		DateTime dateAbove = formatter.parseDateTime(priviousTime);
		DateTime dateCurrent = formatter.parseDateTime(currentTime);

		int minDifference = Minutes.minutesBetween(dateAbove, dateCurrent).getMinutes();
		if (minDifference == 0 || minDifference == 1) {
			return true;
		} else if (minDifference > 1) {
			dateDifference = minDifference;
			return false;
		} else {
			return false;
		}
	}

	public static List<String> getMissingRows(String priviousTime, String currentTime) {
		List<String> customList = new ArrayList<>();

		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy.MM.dd HH:mm");
		DateTime dateAbove = formatter.parseDateTime(priviousTime);

		for (int i = 1; i < dateDifference + 1; i++) {
			DateTime dateCurrent = dateAbove.plusMinutes(i);

			String date = dateCurrent.toString().substring(0, 4) + "." + dateCurrent.toString().substring(5, 7) + "."
					+ dateCurrent.toString().substring(8, 10);

			String time = dateCurrent.toString().substring(11, 13) + ":" + dateCurrent.toString().substring(14, 16);

			StringBuilder builder = new StringBuilder();
			builder.append(date); // date
			builder.append("\t");
			builder.append(time); // time
			builder.append("\t");
			builder.append("0"); // value 1
			builder.append("\t");
			builder.append("0"); // value 2
			builder.append("\t");
			builder.append("0"); // value 3
			builder.append("\t");
			builder.append("0"); // value 4
			builder.append("\t");
			builder.append("0"); // value 5
			
			String dateText = dateCurrent.toString().substring(0, 4) + "/" + dateCurrent.toString().substring(5, 7) + "/"
					+ dateCurrent.toString().substring(8, 10);

			DateTimeFormatter customDateFormator = DateTimeFormat.forPattern("yyyy/MM/dd");
			DateTime customDate = customDateFormator.parseDateTime(dateText);

			builder.append("\t");
			builder.append(customDate.getDayOfWeek()); // value 6
			
			customList.add(builder.toString());
		}

		return customList;
	}

	public static void generateFinalizedArray() {
		for (int i = 0; i < finalizeArray.size(); i++) {
			String[] rowDataSet = finalizeArray.get(i).split("\t");

			// check whether row data contains zero
			if (rowDataSet[2].equals("0")) {

				String[] priviousOkRowDataSet = finalizeArray.get(i - 1).split("\t");
				boolean checkPoint = true;
				int count = 1;

				while (checkPoint) {
					String[] tempRowDataSet = finalizeArray.get(i + count).split("\t");
					if (!tempRowDataSet[2].equals("0")) {
						
						StringBuilder builder = new StringBuilder();
						builder.append(rowDataSet[0]); // date
						builder.append("\t");
						builder.append(rowDataSet[1]); // time
						builder.append("\t");
						builder.append("" + getAVG(priviousOkRowDataSet[2], tempRowDataSet[2])); // value
																									// 1
						builder.append("\t");
						builder.append("" + getAVG(priviousOkRowDataSet[3], tempRowDataSet[3])); // value
																									// 2
						builder.append("\t");
						builder.append("" + getAVG(priviousOkRowDataSet[4], tempRowDataSet[4])); // value
																									// 3
						builder.append("\t");
						builder.append("" + getAVG(priviousOkRowDataSet[5], tempRowDataSet[5])); // value
																									// 4
						builder.append("\t");
						builder.append("0"); // value 5

						builder.append("\t");
						builder.append(rowDataSet[7]); // day of the week
						
						finalizeArray.set(i, builder.toString());	
						addAfterRowDataValidityCheck(rowDataSet[0], rowDataSet[1], builder);
						checkPoint = false;
					} else {
						checkPoint = true;
					}

					count += 1;
				}
			} else {
				finalizeFixedArray.add(finalizeArray.get(i));
			}
		}
	}

	public static double getAVG(String no1, String no2) {
		return round((((Double.valueOf(no1)) + (Double.valueOf(no2))) / 2), 4);
	}

	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
	public static void addAfterRowDataValidityCheck(String date, String time, StringBuilder builder){
		DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy/MM/dd HH:mm");
		DateTimeFormatter timeFormatter = DateTimeFormat.forPattern("HH:mm");
		
		String dateTimeString = date.replace(".", "/") + " " + time;
		
		DateTime dateForValidityCheck = dateTimeFormatter.parseDateTime(dateTimeString);
		DateTime timeOfTheDay = timeFormatter.parseDateTime(time);
		
		int dayOfTheWeek = dateForValidityCheck.getDayOfWeek();
		int hour = timeOfTheDay.getHourOfDay();
		int min = timeOfTheDay.getMinuteOfDay();
		
		if(dayOfTheWeek == 5 || dayOfTheWeek == 6 || dayOfTheWeek == 7){
			if(dayOfTheWeek == 6){
				// not add to array
			} else if(dayOfTheWeek == 5){
				if(hour>=17){
					// not add to array
					if(hour==17){
						if(min==0){
							System.out.println("its hour 17 min 0");
							finalizeFixedArray.add(builder.toString());
						}
					}else{
						// not add to array
					}
				}else{
					// add to array
					finalizeFixedArray.add(builder.toString());
				}
			} else if (dayOfTheWeek == 7){
				if(hour>=0 && hour<=16){
					// not add to array
				} else if(hour==17){
					if(min == 0){
						// not add to array
					} else {
						// add to array
						finalizeFixedArray.add(builder.toString());
					}
					
				} else{
					// add to array others
					finalizeFixedArray.add(builder.toString());
				}
			} else {
				// add to array
				finalizeFixedArray.add(builder.toString());
			}
		} else {
			finalizeFixedArray.add(builder.toString());
		}
	}
}
